import { useState } from 'react';
import { Send, Mic } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';

interface ChatInputProps {
  onSendMessage: (text: string) => void;
  disabled?: boolean;
  placeholder?: string;
}

export const ChatInput = ({ 
  onSendMessage, 
  disabled = false, 
  placeholder = "Ask about Hyderabad..." 
}: ChatInputProps) => {
  const [message, setMessage] = useState('');
  
  const handleSend = () => {
    if (message.trim() && !disabled) {
      onSendMessage(message.trim());
      setMessage('');
    }
  };
  
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };
  
  return (
    <div className="flex gap-3 items-end p-4 bg-surface-elevated/80 backdrop-blur-md border-t border-border">
      <div className="flex-1 relative">
        <Textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder={placeholder}
          disabled={disabled}
          rows={1}
          className="resize-none bg-card/50 border-card-border focus:border-primary/50 rounded-xl pr-12 min-h-[48px] max-h-32"
        />
        <Button
          variant="ghost"
          size="sm"
          className="absolute right-2 top-2 w-8 h-8 text-muted-foreground hover:text-accent"
          disabled={disabled}
        >
          <Mic className="w-4 h-4" />
        </Button>
      </div>
      
      <Button
        onClick={handleSend}
        disabled={disabled || !message.trim()}
        className="h-12 w-12 bg-gradient-primary hover:shadow-glow transition-all duration-200"
        size="icon"
      >
        <Send className="w-5 h-5" />
      </Button>
    </div>
  );
};