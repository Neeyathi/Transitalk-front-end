import botAvatar from '@/assets/transitalk-bot-avatar.png';

export const LoadingMessage = () => {
  return (
    <div className="flex gap-3 mb-6 message-enter">
      <div className="flex-shrink-0">
        <div className="w-10 h-10 rounded-full bg-gradient-primary flex items-center justify-center shadow-glow">
          <img 
            src={botAvatar} 
            alt="Transitalk Bot" 
            className="w-8 h-8 rounded-full"
          />
        </div>
      </div>
      
      <div className="flex-1 max-w-[80%]">
        <div className="bg-card/80 border border-card-border p-4 rounded-2xl rounded-tl-sm backdrop-blur-sm">
          <div className="flex items-center gap-2">
            <div className="flex gap-1">
              <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
              <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            </div>
            <span className="text-sm text-muted-foreground">Transitalk is thinking...</span>
          </div>
        </div>
      </div>
    </div>
  );
};