import { Globe } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface ChatHeaderProps {
  currentLanguage?: string;
}

const languageFlags: Record<string, string> = {
  'en': '🇺🇸',
  'hi': '🇮🇳',
  'te': '🇮🇳',
  'ur': '🇵🇰',
  'ta': '🇮🇳',
  'ar': '🇸🇦',
  'bn': '🇧🇩',
  'fr': '🇫🇷',
  'es': '🇪🇸',
  'de': '🇩🇪',
  'pt': '🇵🇹',
  'ru': '🇷🇺',
  'zh': '🇨🇳',
  'ja': '🇯🇵',
  'ko': '🇰🇷'
};

const languageNames: Record<string, string> = {
  'en': 'English',
  'hi': 'हिंदी',
  'te': 'తెలుగు',
  'ur': 'اردو',
  'ta': 'தமிழ்',
  'ar': 'العربية',
  'bn': 'বাংলা',
  'fr': 'Français',
  'es': 'Español',
  'de': 'Deutsch',
  'pt': 'Português',
  'ru': 'Русский',
  'zh': '中文',
  'ja': '日本語',
  'ko': '한국어'
};

export const ChatHeader = ({ currentLanguage = 'en' }: ChatHeaderProps) => {
  return (
    <div className="sticky top-0 z-50 bg-surface/95 backdrop-blur-md border-b border-border">
      <div className="px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <h1 className="text-2xl font-bold gradient-text">
              Transitalk
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Talk to Hyderabad — culture, travel, and environment in your own tongue
            </p>
          </div>
          
          <div className="flex items-center gap-3">
            <Badge 
              variant="outline" 
              className="bg-card/50 border-card-border text-card-foreground px-3 py-1 text-sm"
            >
              <Globe className="w-3 h-3 mr-2" />
              <span className="mr-1">{languageFlags[currentLanguage] || '🌐'}</span>
              {languageNames[currentLanguage] || 'Auto-detect'}
            </Badge>
          </div>
        </div>
      </div>
    </div>
  );
};