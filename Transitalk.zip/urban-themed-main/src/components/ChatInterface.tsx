import { useState, useRef, useEffect } from 'react';
import { ChatHeader } from './ChatHeader';
import { ChatMessage, Message, MessageType } from './ChatMessage';
import { LoadingMessage } from './LoadingMessage';
import { QuickActions } from './QuickActions';
import { ChatInput } from './ChatInput';
import { useToast } from '@/hooks/use-toast';

interface ChatResponse {
  reply: string;
  lang: string;
}

export const ChatInterface = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "नमस्कार! I'm Transitalk, your multilingual guide to Hyderabad. Ask me about tourism, smart city services, or environmental initiatives in any language!",
      isBot: true,
      type: 'helpful',
      timestamp: new Date()
    }
  ]);
  
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // Determine message type based on content keywords
  const determineMessageType = (text: string): MessageType | undefined => {
    const lowerText = text.toLowerCase();
    
    if (lowerText.includes('tourist') || lowerText.includes('visit') || lowerText.includes('attraction') || 
        lowerText.includes('travel') || lowerText.includes('heritage') || lowerText.includes('culture')) {
      return 'tourism';
    }
    
    if (lowerText.includes('environment') || lowerText.includes('green') || lowerText.includes('sustainability') ||
        lowerText.includes('pollution') || lowerText.includes('climate') || lowerText.includes('eco')) {
      return 'environment';
    }
    
    return 'helpful';
  };

  const sendMessage = async (text: string) => {
    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      text,
      isBot: false,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    try {
      // API call to backend
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data: ChatResponse = await response.json();
      
      // Add bot response
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: data.reply,
        isBot: true,
        type: determineMessageType(data.reply),
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botMessage]);
      setCurrentLanguage(data.lang);
      
    } catch (error) {
      console.error('Failed to send message:', error);
      
      // Fallback demo response
      const demoResponses = {
        tourism: "🏛️ Hyderabad offers incredible attractions like the iconic Charminar, magnificent Golkonda Fort, serene Hussain Sagar Lake, and the grand Chowmahalla Palace. Don't miss the bustling Laad Bazaar for traditional bangles and pearls!",
        city: "🏙️ Hyderabad's smart city initiatives include digital governance through TS-iPASS, smart traffic management systems, Wi-Fi hotspots across the city, and the innovative GHMC app for municipal services. The HITEC City showcases our tech prowess!",
        environment: "🌱 Hyderabad is committed to sustainability with initiatives like Haritha Haram (green program), Metro Rail reducing carbon footprint, KBR National Park conservation, and waste management through Swachh Hyderabad mission."
      };
      
      let demoText = demoResponses.tourism;
      const lowerText = text.toLowerCase();
      
      if (lowerText.includes('smart') || lowerText.includes('city') || lowerText.includes('service')) {
        demoText = demoResponses.city;
      } else if (lowerText.includes('environment') || lowerText.includes('green') || lowerText.includes('sustainability')) {
        demoText = demoResponses.environment;
      }
      
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: demoText,
        isBot: true,
        type: determineMessageType(demoText),
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botMessage]);
      
      toast({
        title: "Demo Mode",
        description: "Using demo responses. Connect to backend for full functionality.",
        variant: "default",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickAction = (query: string) => {
    sendMessage(query);
  };

  return (
    <div className="flex flex-col h-screen max-h-screen bg-gradient-background">
      <ChatHeader currentLanguage={currentLanguage} />
      
      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-4">
        {messages.map((message) => (
          <ChatMessage key={message.id} message={message} />
        ))}
        
        {isLoading && <LoadingMessage />}
        
        <div ref={messagesEndRef} />
      </div>
      
      {/* Quick Actions */}
      <QuickActions onActionClick={handleQuickAction} disabled={isLoading} />
      
      {/* Input Area */}
      <ChatInput onSendMessage={sendMessage} disabled={isLoading} />
      
      {/* Footer */}
      <div className="px-4 py-2 text-center border-t border-border bg-surface/30">
        <p className="text-xs text-muted-foreground">
          Powered by HiBuddy Hackathon
        </p>
      </div>
    </div>
  );
};