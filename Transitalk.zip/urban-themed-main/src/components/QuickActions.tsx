import { MapPin, Building, Leaf } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface QuickAction {
  id: string;
  label: string;
  icon: React.ReactNode;
  query: string;
  variant: 'tourism' | 'city' | 'environment';
}

const quickActions: QuickAction[] = [
  {
    id: 'tourist',
    label: 'Tourist Info',
    icon: <MapPin className="w-4 h-4" />,
    query: "What are the must-visit tourist attractions in Hyderabad?",
    variant: 'tourism'
  },
  {
    id: 'city',
    label: 'Smart City Services',
    icon: <Building className="w-4 h-4" />,
    query: "How can I access Hyderabad's smart city services and digital infrastructure?",
    variant: 'city'
  },
  {
    id: 'environment',
    label: 'Environment Tips',
    icon: <Leaf className="w-4 h-4" />,
    query: "What are the environmental initiatives and sustainability practices in Hyderabad?",
    variant: 'environment'
  }
];

const variantStyles = {
  tourism: 'bg-info/10 hover:bg-info/20 border-info/30 text-info hover:text-info-foreground',
  city: 'bg-primary/10 hover:bg-primary/20 border-primary/30 text-primary hover:text-primary-foreground',
  environment: 'bg-environment/10 hover:bg-environment/20 border-environment/30 text-environment hover:text-environment-foreground'
};

interface QuickActionsProps {
  onActionClick: (query: string) => void;
  disabled?: boolean;
}

export const QuickActions = ({ onActionClick, disabled = false }: QuickActionsProps) => {
  return (
    <div className="px-4 py-3 border-t border-border bg-surface/50">
      <div className="flex flex-wrap gap-2 justify-center">
        {quickActions.map((action) => (
          <Button
            key={action.id}
            variant="outline"
            size="sm"
            onClick={() => onActionClick(action.query)}
            disabled={disabled}
            className={`
              ${variantStyles[action.variant]}
              border backdrop-blur-sm hover-lift transition-all duration-200
              text-xs px-3 py-2 h-auto
            `}
          >
            {action.icon}
            <span className="ml-2">{action.label}</span>
          </Button>
        ))}
      </div>
    </div>
  );
};