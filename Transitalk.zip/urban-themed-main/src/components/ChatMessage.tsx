import { useState } from 'react';
import { Copy, Check, Bot, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import botAvatar from '@/assets/transitalk-bot-avatar.png';

export type MessageType = 'helpful' | 'tourism' | 'environment';

export interface Message {
  id: string;
  text: string;
  isBot: boolean;
  type?: MessageType;
  timestamp: Date;
}

interface ChatMessageProps {
  message: Message;
}

const messageTypeStyles = {
  helpful: 'bg-gradient-to-r from-success/20 to-success/10 border-success/30',
  tourism: 'bg-gradient-to-r from-info/20 to-info/10 border-info/30', 
  environment: 'bg-gradient-to-r from-environment/20 to-environment/10 border-environment/30',
};

export const ChatMessage = ({ message }: ChatMessageProps) => {
  const [copied, setCopied] = useState(false);
  
  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(message.text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  if (message.isBot) {
    return (
      <div className="flex gap-3 mb-6 message-enter">
        <div className="flex-shrink-0">
          <div className="w-10 h-10 rounded-full bg-gradient-primary flex items-center justify-center shadow-glow">
            <img 
              src={botAvatar} 
              alt="Transitalk Bot" 
              className="w-8 h-8 rounded-full"
            />
          </div>
        </div>
        
        <div className="flex-1 max-w-[80%]">
          <div className={cn(
            "p-4 rounded-2xl rounded-tl-sm border backdrop-blur-sm",
            message.type ? messageTypeStyles[message.type] : "bg-card/80 border-card-border"
          )}>
            <p className="text-card-foreground leading-relaxed whitespace-pre-wrap">
              {message.text}
            </p>
          </div>
          
          <div className="flex items-center gap-2 mt-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={copyToClipboard}
              className="h-7 px-2 text-xs text-muted-foreground hover:text-foreground"
            >
              {copied ? (
                <Check className="w-3 h-3 mr-1" />
              ) : (
                <Copy className="w-3 h-3 mr-1" />
              )}
              {copied ? 'Copied!' : 'Copy'}
            </Button>
            <span className="text-xs text-muted-foreground">
              {message.timestamp.toLocaleTimeString([], { 
                hour: '2-digit', 
                minute: '2-digit' 
              })}
            </span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-end mb-6 message-enter">
      <div className="flex gap-3 max-w-[80%]">
        <div className="flex-1">
          <div className="bg-gradient-primary p-4 rounded-2xl rounded-tr-sm shadow-glow">
            <p className="text-primary-foreground leading-relaxed whitespace-pre-wrap">
              {message.text}
            </p>
          </div>
          
          <div className="flex items-center justify-end gap-2 mt-2">
            <span className="text-xs text-muted-foreground">
              {message.timestamp.toLocaleTimeString([], { 
                hour: '2-digit', 
                minute: '2-digit' 
              })}
            </span>
          </div>
        </div>
        
        <div className="flex-shrink-0">
          <div className="w-10 h-10 rounded-full bg-muted/50 flex items-center justify-center">
            <User className="w-5 h-5 text-muted-foreground" />
          </div>
        </div>
      </div>
    </div>
  );
};